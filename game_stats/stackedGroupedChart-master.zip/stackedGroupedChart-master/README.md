Stacked and Grouped Bar Chart
===================

Stacked Grouped Bar Chart built using D3.js

Usage
=====
You can modify each group's stacks using innerColumns Object.

    var innerColumns = {

      "column1" : ["column_name", "column_name"],
  
      "column2" : ["column_name"],
  
      "column3" : ["column_name"]
  
    }

Gist
====
https://gist.github.com/4629518#file-index-html

Demo
====
http://bl.ocks.org/4629518
